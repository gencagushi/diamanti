<?php include 'parts/header.php'; ?>

    <!-- Page Content -->
    <div class="container">

        <hr class="featurette-divider">

        <!-- First Featurette -->
        <div class="featurette" id="about">
            <img class="featurette-image img-circle img-responsive pull-right" src="repository/student-1.jpg">
            <h2 class="featurette-heading">Why we do it?</h2>
            <p class="lead">
                The constant changes in societys needs, the global demands for knowledge and especially the rapid
                advancements of Information and Communication Technologies (ICT) are changing educations structures,
                cultures and processes. Here, at CITY College, the International Faculty of the University of Sheffield,
                we are committed to providing high quality education and strive to be internationally recognised for
                academic excellence, driven by pure and applied research. In our constant effort to improve the
                educational quality, the utilisation of technology is one of our strategic objectives since it provides
                innovative alternatives to teach, learn, communicate, and share knowledge.
            </p>
        </div>

        <hr class="featurette-divider">

        <!-- Second Featurette -->
        <div class="featurette" id="services">
            <img class="featurette-image img-circle img-responsive pull-left" src="repository/student-2.jpg">
            <h2 class="featurette-heading">More about us.. </h2>
            <p class="lead">
                The EDucational InformaTics - EDIT is a multidisciplinary research group of CITY College and is directed
                by the Department of Computer Science. In collaboration with the South-East European Research Centre
                (SEERC), EDIT engages in academically rigorous and socially meaningful research focused on applications
                of information and communication technologies and instructional design for any educational environment.
                Our goal is to investigate innovative methods that facilitate teaching and foster learning and meet
                learners' growing needs, as well as, social and technological changes of the 21st century.
            </p>
        </div>

        <hr class="featurette-divider">
        <!-- Third Featurette -->
        <div class="featurette" id="contact">
            <img class="featurette-image img-circle img-responsive pull-right" src="repository/sheffield.jpg">
            <h2 class="featurette-heading">About our university !</h2>
            <p class="lead">
                The University of Sheffield International Faculty, CITY College, is one of the six faculties within
                the University and the only one operating overseas. Bridging the UK with the South East and Eastern Europe,
                the International Faculty offers to students the unique opportunity to study for a top class British
                degree of the University of Sheffield in their region. Stretching across borders, the International Faculty
                embraces internationalisation and gives to its students the experiences, curricula and traditions of the
                University. We aspire to transfer knowledge, in-depth research and academic excellence across the region
                through our education hubs. Read more here.
            </p>
        </div>
        <hr class="featurette-divider">
    </div>

<?php include 'parts/footer.php'; ?>