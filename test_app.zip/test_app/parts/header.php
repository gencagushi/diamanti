<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Educational Informatics Research Group</title>
        <meta name="mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black">
        <meta name="apple-mobile-web-app-title" content="Educational Informatics Research Group">
        <meta name="description" content="City College">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

        <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">

        <link rel="stylesheet" href="inc/css/vendor/bootstrap.min.css">
        <link rel="stylesheet" href="inc/css/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="inc/css/style.css">

        <script src="https://maps.googleapis.com/maps/api/js"></script>
        <script src="inc/js/vendor/jquery-1.11.3.min.js"></script>
        <script src="inc/js/vendor/jquery.fancybox.js"></script>
        <script src="inc/js/vendor/jquery.fancybox-media.js"></script>
        <script src="inc/js/vendor/jquery.bxslider.min.js"></script>
        <script src="inc/js/vendor/jquery.mmenu.all.min.js" type="text/javascript"></script>
        <script src="inc/js/vendor/jquery.validate.min.js" type="text/javascript"></script>
        <script src="inc/js/vendor/skrollr.min.js" type="text/javascript"></script>
        <script src="inc/js/vendor/bootstrap.min.js" type="text/javascript"></script>
        <script src="inc/js/main.js"></script>
    </head>

    <body>
    <div class="header-section">
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Start Bootstrap</a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="members.php">Members</a></li>
                        <li><a href="publications.php">Publications</a></li>
                        <li><a href="projects.php">Projects</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#">Member? Log In <span class="glyphicon glyphicon-user"></span></a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
            <!-- /.container -->
        </nav>

        <!-- Full Width Image Header with Logo -->
        <!-- Image backgrounds are set within the full-width-pics.css file. -->
        <header class="image-bg-fluid-height">
            <img class="img-responsive img-center" src="http://placehold.it/200x200&text=Logo" alt="">
        </header>
    </div>






        

