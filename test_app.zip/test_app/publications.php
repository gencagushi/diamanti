<?php include 'parts/header.php'; ?>
    <div class="container">

        <!-- Introduction Row -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Publications
                    <small>Search</small>
                </h1>
                <form>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label>Keyword</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label>Author</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label>Year</label>
                                <input type="text" class="form-control">
                            </div>
                            <div class="col-md-3 submit-bttn-publications-col">
                                <button type="button" class="btn btn-primary submit-bttn-publications">Search<span class="glyphicon glyphicon-search search-icon"></span></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>
            <!-- Projects Row -->
            <div class="row">
                <div class="media">
                    <div class="media-left">
                        <span class="glyphicon glyphicon-paperclip"></span>
                    </div>
                    <div class="media-body">
                        <h4>
                            Heemskerk J, Tobin AJ, Ravina B. 2002. From chemical to drug: neurodegeneration drug screening and the ethics of clinical trials. Nat Neurosci. 5 Suppl:1027–1029.
                        </h4>
                    </div>
                </div>
            </div>
            <hr>

            <nav>
                <ul class="pagination pagination-lg">
                    <li>
                        <a href="#" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <li><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li>
                        <a href="#" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>

        </div>



    </div>
<?php include 'parts/footer.php'; ?>