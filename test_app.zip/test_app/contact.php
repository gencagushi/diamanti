<?php include 'parts/header.php'; ?>
    <div class="container">

        <!-- Introduction Row -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Contact
                    <small>Search</small>
                </h1>
                <p>
                    For any inquires or comments about the Educational Informatics Research Group please contact us.
                </p>
            </div>
        </div>

        <div class="col-md-12">
            <div class="contact-2">
                <div class="contact-section">
                    <div class="left">
                        <div id="map-canvas" class="">
                            <span class="circle-map"></span>
                            <div id="googleMap"></div>
                <span class="borders-style">
                </span>
                        </div>
                    </div>
                    <div class="right">

                        <div class="contact-content">
                            <p>
                                Arbëria 3 Ahmet Krasniqi p.o. Box 263
                                10000 Pristina, Republic of Kosovo
                            </p>
                            <div class="short-info">
                                <p><strong>Office </strong>+381 38 606 126/107</p>

                                <p><strong>Support </strong>+37745622975</p>
                            </div>
                            <div class="short-info">
                                <p><strong>Office </strong>+381 38 606 126/107</p>

                                <p><strong>Support </strong>+37745622975</p>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
            </div>
        </div>

    </div>

<?php include 'parts/footer.php'; ?>