<?php include 'parts/header.php'; ?>
    <div class="container about-section">

        <!-- Introduction Row -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">About Us
                    <small>It's Nice to Meet You!</small>
                </h1>
                <p>	City College is committed to initiatives that foster a culture of academic excellence. In the efforts
                    to systematically strengthen the quality of education, technology is perceived as a catalyst that
                    modernizes teaching and learning and as means of improving academic achievement and teacher effectiveness.
                    In 2003, City College and the South-East European Research Centre (SEERC) established the Educational
                    Informatics group for conducting multidisciplinary research focused on teaching, learning and technology.
                    The EDIT research group is directed by the Computer Science Department of the college and belongs to the
                    Information and Knowledge Management Research Cluster of SEERC.
                    The vision of the EDIT group is to establish preeminence and leadership in the field of educational
                    technology by engaging and facilitating activity related to educational innovation.
                </p>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Services Panels</h2>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-graduation-cap fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h2>Mission</h2>
                        <ul>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Engage in academically rigorous and socially meaningful research in the fields of educational technology, instructional design and curriculum development
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                prepare individuals at the doctoral level to serve as outstanding educators and leaders in the field of educational informatics
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                collaborate with universities, research institutes and non-profit organizations to further the understanding and application of teaching and learning technologies
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-university fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h2>Research Aims</h2>
                        <ul>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Design, develop and evaluate innovative educational solutions that seamlessly integrate pedagogy and technology
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Analyse challenges and opportunities related to the application of ICT in education
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Investigate social and cultural issues raised by the use of ICT in education
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Explore and formulate new pedagogic models, teaching strategies, informatics curricula and training programs
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-6">
                <div class="panel panel-default text-center">
                    <div class="panel-heading">
                        <span class="fa-stack fa-5x">
                              <i class="fa fa-circle fa-stack-2x text-primary"></i>
                              <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
                        </span>
                    </div>
                    <div class="panel-body">
                        <h2>Thematic hours</h2>
                        <ul>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Educational technology, virtual learning environments, e-learning and distance learning, instructional design
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Lifelong learning, networked learning, ambient learning, collaborative learning, blended learning
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Investigate social and cultural issues raised by the use of ICT in education
                            </li>
                            <li>
                                <span class="glyphicon glyphicon-minus"></span>
                                Curriculum development, computer science education, entrepreneurial education, higher education, vocational training
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

        <!-- Team Members Row -->


        <hr>


    </div>
<?php include 'parts/footer.php'; ?>